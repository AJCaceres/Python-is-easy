numbers = 1

for numbers in xrange(1,100):
	if (numbers%3 == 0) && (numbers%5==0):
		print("FizzBuzz")
	elif numbers%3 = 0:
		print("Fizz")
	elif numbers%5 = 0:
		print("Buzz")
	else print(numbers)