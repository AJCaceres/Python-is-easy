

print("Inserte el número de columnas y filas para el tablero")
numero = int(input())
# if numero%2==1:
# 	for x in range(numero):
# 		if x %2 == 0:
# 			for y in range(1,numero+1):
# 				if y%2 == 1:
# 					if y!=numero:
# 						print(" ", end="")
# 					else:
# 						print(" ")
# 				else:
# 					print("|",end="")
# 		else:
# 			print("-"*numero)

def drawBoard(numero):
	if numero%2==1:
		for x in range(numero):
			if x %2 == 0:
				for y in range(1,numero+1):
					if y%2 == 1:
						if y!=numero:
							print(" ", end="")
						else:
							print(" ")
					else:
						print("|",end="")
			else:
				print("-"*numero)
	else:
		for x in range(numero):
			print("x"*numero)

drawBoard(numero)