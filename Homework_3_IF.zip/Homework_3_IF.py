

def equalNumbers(a,b,c):
	a = int(a)
	b = int(b)
	c = int(c)

	if a == b or a == c or b == c:
		return True
	else:
		return False

equalNumbers("3",2,3)
 	