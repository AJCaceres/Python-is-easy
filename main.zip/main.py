"""
Homework no. 1
Variables

This lesson is to know how to use variables.
I need to list the characteristics of my favorite song.

"""

Name = "Legends"
Artist = "Juice WRLD"
Album = "Legends"
Genre = "Hip-hop/ Rap"
DurationInSeconds = 192
YearOfPublish = 2018
SimilarArtists = "Pop Smoke and Lil Peep"
Mood = "Depressive"
Producer = "Russ Chell and Take a Daytrip" 

print(Name)
print(Artist)
print(Album)
print(Genre)
print(DurationInSeconds)
print(YearOfPublish)
print(SimilarArtists)
print(Mood)
print(Producer)